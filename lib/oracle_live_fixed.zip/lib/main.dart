
import 'package:flutter/material.dart';
import 'screens/home/home_screen.dart';

void main() {
  runApp(const OracleLiveApp());
}

class OracleLiveApp extends StatelessWidget {
  const OracleLiveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Oracle Live',
      home: HomeScreen(),
    );
}
}
