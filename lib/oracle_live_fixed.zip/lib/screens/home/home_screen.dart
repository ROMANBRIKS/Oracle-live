
import 'package:flutter/material.dart';
import '../live/live_screen.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Oracle Live')),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => LiveScreen(channelName: "testChannel"),
              ),
            );
          },
          child: Text("Go Live"),
        ),
      ),
    );
  }
}
