
import 'package:flutter/material.dart';
import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import '../../config/agora_config.dart';

class LiveScreen extends StatefulWidget {
  final String channelName;

  const LiveScreen({required this.channelName});

  @override
  State<LiveScreen> createState() => _LiveScreenState();
}

class _LiveScreenState extends State<LiveScreen> {
  late RtcEngine _engine;

  @override
  void initState() {
    super.initState();
    initAgora();
  }

  Future<void> initAgora() async {
    _engine = createAgoraRtcEngine();
    await _engine.initialize(RtcEngineContext(appId: agoraAppId));
    await _engine.enableVideo();
    await _engine.joinChannel(
      token: "",
      channelId: widget.channelName,
      uid: 0,
      options: ChannelMediaOptions(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Live")),
      body: Center(child: Text("Live Stream Running")),
    );
  }
}
